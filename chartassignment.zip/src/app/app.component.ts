import { Component,OnInit, ViewChild } from '@angular/core';
import { WeatherService } from './service/weather.service';
import { UserModel } from './model/usermodel';
import { Chart } from 'chart.js';
import { ChartData } from './model/chartData';
import { PassingValues } from './model/passingvalue';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  allData: UserModel;
  allDataArray:ChartData[];
  chart = [];
   chartData:[];
   // chartData:ChartData;
   eventTitle=[];
   passingValues = new PassingValues;
  sent=[];
  bounced=[];
  all=[];
  clicked=[];
  complaint=[];
  opened=[];
  unsubscribed=[];
  reject=[];
  maxvalue:number;
 
  constructor(private _service: WeatherService) {
  }

  
  ngOnInit() {
    //this.getData();
    
    
   this. getData();
   this. getChartDataFromApi();
   this.passingValues.from="2019-08-10";
   this.passingValues.to="2019-08-11"
  }
  displayedColumns: string[] = ['title', 'datetime', 'status', 'recipients'];
  dataSource:any;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

 

  getChartDataFromApi() {
    this._service.dailyForecastFromApi(this.passingValues).subscribe(
      response => {
        this.allDataArray =response;
        this.dataSource = this.allDataArray;
        
        for (let i = 0; i < this.allDataArray.length; i++) {
          this.eventTitle.push(this.allDataArray[i].title);
          this.sent.push(this.allDataArray[i].report.Sent);
          this.bounced.push(this.allDataArray[i].report.Bounced);
          this.all.push(this.allDataArray[i].report.All);
          this.clicked.push(this.allDataArray[i].report.Clicked);
          this.complaint.push(this.allDataArray[i].report.Complaint);
          this.opened.push(this.allDataArray[i].report.Opened);
          this.unsubscribed.push(this.allDataArray[i].report.Unsubscribe);
          this.reject.push(this.allDataArray[i].report.reject);
          this.maxvalue=40/5
        }
        console.log("after multiples :"+this.sent);
        console.log("chart data from api:"+JSON.stringify(this.eventTitle));
        this.chart = new Chart('canvas', {
          type: 'line',
          data: {
            labels:this.eventTitle,

            datasets: [
              {
                data:this.sent,
                borderColor: '#3cba9f',
                fill: false
              },
              {
                data: this.complaint,
                borderColor: '#ff3300',
                fill: false
              },
              {
                data: this.opened,
                borderColor: '#0000FF',
                fill: false
              },
              {
                data: this.clicked,
                borderColor: '#FF1493',
                fill: false
              },
              {
                data: this.bounced,
                borderColor: '#FF4500',
                fill: false
              },
              {
                data: this.unsubscribed,
                borderColor: '#ffcc00',
                fill: false
              },
              {
                data: this.reject,
                borderColor: '#8B0000',
                fill: false
              },
              {
                data: this.all,
                borderColor: '#8B008B',
                fill: false
              },
            ]
          },
          options: {
            legend: {
              display: true
            },
            scales: {
              xAxes: [{
                ticks: {
                  fontSize:8.5,
                  autoSkip:false,
                  maxRotation: 0,
                  minRotation: 0
                 
              },
                
                stacked: true,
                display: true,
               
              },
              ],
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  min: 0,
                  max: this.maxvalue
              },
                type: 'linear',
                display: true
              }]
            }
          }
        })
      })
      }

  getData() {
    this._service.getWeatherReport().subscribe(
      response => {
        this.allData = response;
        let temp_max=[this.allData.list[0].main.temp_max,this.allData.list[1].main.temp_max,this.allData.list[2].main.temp_max];
        let temp_min=[this.allData.list[0].main.temp_min,this.allData.list[1].main.temp_min,this.allData.list[2].main.temp_min];
        // for (let index = 0; index < ; index++) {}
        // let temp_min = response['list'].map(res => res.main.temp_min);
        // let alldates = response['list'].map(res => res.dt);

        
      })
  }
}
