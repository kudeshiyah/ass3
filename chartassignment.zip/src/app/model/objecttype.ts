import { Main } from './main';
import { Wind } from './wind';
import { Clouds } from './cloud';
import { Weather } from './weather';
import { Rain } from './Rain';
export class ObjectType{
    main:Main;
    wind:Wind;
    clouds:Clouds;
    weather:Weather;
    rain:Rain;
    dt:any;
}