export class Weather{
    id: any;
    main: any;
    description: any;
    icon: any;
}