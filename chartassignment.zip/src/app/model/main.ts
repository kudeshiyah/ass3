export class Main {
    temp: any;
    temp_min: any;
    temp_max: any;
    pressure: any;
    sea_level: any;
    grnd_level:any;
    humidity: any;
}