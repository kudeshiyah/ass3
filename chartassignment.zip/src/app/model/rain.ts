export class Rain{
 ts:any;  
}