import { ObjectType } from './objecttype';
export class UserModel{
    message:any;
    cod: any;
    city_id: any;
    calctime: any;
    cnt: any;
    list: ObjectType;
}