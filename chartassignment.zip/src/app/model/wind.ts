export class Wind{
    speed: any;
    deg: any;
}