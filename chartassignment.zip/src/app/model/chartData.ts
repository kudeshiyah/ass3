import { DripId } from './dripId';
import { Report } from './report';

export class ChartData{
    successStatus:any;
        createdAt:any;
        status: boolean;
        recipients: any;
        agent: any;
        dripId: DripId;
        sequenceType: any;
        sequence: any;
        datetime: any;
        time: any;
        date:any;
        title: any;
        _id: any;
        report:Report;
}