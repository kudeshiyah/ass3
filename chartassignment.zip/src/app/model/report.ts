export class Report {
    Sent: any;
    Complaint: any;
    Opened: any;
    Clicked: any;
    Bounced: any;
    Unsubscribe:any;
    reject: any;
    All: any;
}