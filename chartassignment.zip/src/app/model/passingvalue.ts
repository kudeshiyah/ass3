export class PassingValues{
    from:any;
    to:any ;
   }
   