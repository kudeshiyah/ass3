export class Clouds{
  all:any;  
} 