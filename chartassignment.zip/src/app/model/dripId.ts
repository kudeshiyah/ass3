export class DripId{
    _id:any;
    title: any;   
}